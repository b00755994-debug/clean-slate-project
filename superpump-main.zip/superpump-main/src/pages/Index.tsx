import Header from "@/components/Header";
import BetaBanner from "@/components/BetaBanner";
import Hero from "@/components/Hero";
import ProblemSolution from "@/components/ProblemSolution";
import Features from "@/components/Features";
import SlackIntegration from "@/components/SlackIntegration";
import Testimonial from "@/components/Testimonial";
import CTA from "@/components/CTA";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <BetaBanner />
      <main>
        <Hero />
        <section id="slack-integration">
          <SlackIntegration />
        </section>
        <section id="solution">
          <ProblemSolution />
        </section>
        <section id="features">
          <Features />
        </section>
        <section id="temoignages">
          <Testimonial />
        </section>
        <CTA />
      </main>
      <Footer />
    </div>
  );
};

export default Index;
