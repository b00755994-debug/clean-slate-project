-- Add RLS policies for UPDATE and DELETE operations on beta_signups
-- Only admins can update beta signups
CREATE POLICY "Only admins can update beta signups"
ON public.beta_signups
FOR UPDATE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Only admins can delete beta signups
CREATE POLICY "Only admins can delete beta signups"
ON public.beta_signups
FOR DELETE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));