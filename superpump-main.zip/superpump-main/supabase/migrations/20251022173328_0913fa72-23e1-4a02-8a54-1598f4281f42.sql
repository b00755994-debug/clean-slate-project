-- Create function to auto-assign admin role to whitelisted emails
CREATE OR REPLACE FUNCTION public.handle_new_user_with_whitelist()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  whitelisted_emails TEXT[] := ARRAY[
    'raphael.charpenet@li.me',
    'b00755994@essec.edu',
    'r.charpenet@free.fr',
    'gaultier@199.vc'
  ];
BEGIN
  -- Check if the new user's email is in the whitelist
  IF NEW.email = ANY(whitelisted_emails) THEN
    -- Insert admin role for this user
    INSERT INTO public.user_roles (user_id, role)
    VALUES (NEW.id, 'admin')
    ON CONFLICT (user_id, role) DO NOTHING;
  ELSE
    -- Insert default user role for non-whitelisted users
    INSERT INTO public.user_roles (user_id, role)
    VALUES (NEW.id, 'user')
    ON CONFLICT (user_id, role) DO NOTHING;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Create trigger to automatically assign roles on user creation
CREATE TRIGGER on_auth_user_created_assign_role
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user_with_whitelist();

-- Assign admin role to any existing users with whitelisted emails
INSERT INTO public.user_roles (user_id, role)
SELECT id, 'admin'::public.app_role
FROM auth.users
WHERE email IN (
  'raphael.charpenet@li.me',
  'b00755994@essec.edu',
  'r.charpenet@free.fr',
  'gaultier@199.vc'
)
ON CONFLICT (user_id, role) DO NOTHING;