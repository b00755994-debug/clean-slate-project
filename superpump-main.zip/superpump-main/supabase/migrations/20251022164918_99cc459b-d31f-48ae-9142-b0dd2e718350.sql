-- Add new columns to beta_signups table
ALTER TABLE public.beta_signups 
ADD COLUMN industry TEXT,
ADD COLUMN referral_source TEXT,
ADD COLUMN linkedin_profile TEXT,
ADD COLUMN user_id UUID REFERENCES auth.users(id);

-- Create index on user_id for faster lookups
CREATE INDEX idx_beta_signups_user_id ON public.beta_signups(user_id);