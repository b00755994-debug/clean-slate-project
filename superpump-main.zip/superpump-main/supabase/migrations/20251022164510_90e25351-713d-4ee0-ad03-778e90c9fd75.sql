-- Create table for beta signups
CREATE TABLE public.beta_signups (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL,
  email TEXT NOT NULL,
  company TEXT NOT NULL,
  company_size TEXT NOT NULL,
  role TEXT NOT NULL,
  linkedin_encouragement TEXT NOT NULL,
  main_difficulty TEXT NOT NULL,
  main_difficulty_other TEXT,
  expected_value TEXT,
  publishing_frequency TEXT NOT NULL,
  most_attractive_benefit TEXT NOT NULL,
  willing_to_pay TEXT NOT NULL,
  monthly_budget TEXT,
  beta_interest TEXT NOT NULL
);

-- Enable Row Level Security
ALTER TABLE public.beta_signups ENABLE ROW LEVEL SECURITY;

-- Policy to allow public inserts (for the beta signup form)
CREATE POLICY "Anyone can submit beta signup"
ON public.beta_signups
FOR INSERT
TO anon
WITH CHECK (true);

-- Policy to allow authenticated users to view all signups (for admin dashboard later)
CREATE POLICY "Authenticated users can view all signups"
ON public.beta_signups
FOR SELECT
TO authenticated
USING (true);

-- Create index on email for faster lookups
CREATE INDEX idx_beta_signups_email ON public.beta_signups(email);

-- Create index on created_at for sorting
CREATE INDEX idx_beta_signups_created_at ON public.beta_signups(created_at DESC);