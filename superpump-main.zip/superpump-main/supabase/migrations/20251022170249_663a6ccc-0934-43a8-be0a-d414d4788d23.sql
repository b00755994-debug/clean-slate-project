-- Add columns for "Autre" specifications
ALTER TABLE public.beta_signups 
ADD COLUMN IF NOT EXISTS referral_source_other text,
ADD COLUMN IF NOT EXISTS role_other text;